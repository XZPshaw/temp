#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 
#include <cstring>
#include <string>
#include <algorithm>

#include <iostream>
#include <netdb.h> 
#include <sstream>
#include <vector>
#include <chrono>
#include <sys/time.h>
using namespace std::chrono;
#include <math.h> 
#include <fstream>
#include <queue>

#include "trands.cpp"
using namespace std;

int main(int argc, char** argv)
{
    int maxBufferSize = 1024;           // maximum buffer size for read/output string
    char outputBuffer[maxBufferSize];   //store the outputContent before write to file
    char hostname[maxBufferSize];       //store hostname
    char messageReceived[maxBufferSize];
    
    int maxClient = 20;                 //maximum client number
    int client_socket[maxClient];       //store the fd for alll client socket
    string pid;
    int port;
    int taskNum = 0;  // keeps track total number of task, display current task index

    int sd, max_sd;
    int valread;

    string outFileName = "server.log";
    ofstream myfile;


    //
    //vector <int> client_socket;
    vector <string> pids;
    vector <int> tran;
    vector <string> readline;


    //start time 
    double start;

    //check the # of argument
    //if only 2 argument, read the thread number, output file id is still 0 by default
    if (argc == 2){
        port = stoi(argv[1]);
        if (port >= 5000 && port <= 64000){
        } else {
            cout << "the port must be in range 5,000 to 64,000";
            return -1;
        }
    //if 3 argument, read the thread number, output file id, assume corrext format
    } else {
        //don't accept if there is only 1 or more than 3 arguments
        cout << "invalid # of arguments, exiting\n";
        return -1;
    }

    //initiaalize all client_socket[] to 0
    for (int i = 0; i < maxClient; ++i){
        //client_socket.push_back(0);
        client_socket[i] = 0;
    }
    int listenfd = 0, connfd = 0;

    fd_set readfds;

    struct sockaddr_in serv_addr;
    struct timeval tv; 

    char buffer[maxBufferSize];

    //create a socket to listen
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd < 0) {
        perror("couldn't setup socket:");
        return -1;
    }
    memset(&serv_addr, '0', sizeof(serv_addr));
    memset(buffer, '0', sizeof(buffer));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);

    int bindfd = bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    if (bindfd < 0){
        perror("fail to bind:");
        return -1;
    }


    int listenCode = listen(listenfd, 10);
    if (listenCode < 0) {
        perror("fail to listen:");
        return -1;
    }

    //print the first port info
    sprintf(outputBuffer,"Using port %d \n", port);
    cout << outputBuffer;
    myfile << outputBuffer;

    int addrlen = sizeof(serv_addr);
    myfile.open(outFileName);

    while (1) {
        //https://www.geeksforgeeks.org/socket-programming-in-cc-handling-multiple-clients-on-server-without-multi-threading/
        //https://stackoverflow.com/questions/30130884/socket-programming-server-w-multiple-clients-in-c
        cout << "enter loop~~\n";

        //clear the socker set
        FD_ZERO(&readfds);
        FD_SET(listenfd, &readfds);
        max_sd = listenfd;

        for (int i = 0; i < maxClient; i++){
            //socket descriptor
            sd = client_socket[i];


            //if valid socket descriptor then add to read list 
            if(sd > 0){
                FD_SET(sd, &readfds);
            }

            //highest file descriptor number, used in select function 
            if(sd > max_sd){
                max_sd = sd;
            }
        }


        //wait for an activity on one of the sockets , timeout is NULL , 
        //current wait indefinitely
        //https://stackoverflow.com/questions/2597608/c-socket-connection-timeout
        tv.tv_sec = 30;
        tv.tv_usec = 0;
        int activity = select( max_sd + 1 , &readfds , NULL , NULL , &tv); 

        if (activity == 0){
            //timeout
            //todo:
            for (int i = 0; i < pids.size(); i++){
                sprintf(outputBuffer, "%4d transactions from %s\n", tran[i], pids[i].c_str());
                cout << outputBuffer;
                myfile << outputBuffer;
            }

            double end = (duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count())/1000;
            sprintf(outputBuffer, "%3.1f transactions/sec (%d/%.2f)\n", taskNum/(end-start - 30), taskNum, end - start - 30);
            cout << "select return 000000000000000000000000000000000000\n";
            break;
        }

        if(activity < 0 && errno!=EINTR){
            perror("select error:");
        }
        //connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);

        //deal with incoming connection 
        int new_socket;
        if (FD_ISSET(listenfd, &readfds)){
            new_socket = accept(listenfd, (struct sockaddr *)&serv_addr, (socklen_t*)&addrlen);
            cout << "new socket:\n";

            if (new_socket < 0)  
            {  
                perror("fail to accept new socket:");  
                return -1;  
            }  

            for (int i = 0; i < maxClient; i++){
                if (client_socket[i] == 0){
                    client_socket[i] = new_socket;
                    break;
                }  
            }

            //https://stackoverflow.com/questions/571394/how-to-find-out-if-an-item-is-present-in-a-stdvector

            cout << "connected" << endl;
        }

        //else its some IO operation on some other socket
        for (int i = 0; i < maxClient; i++)  
        {  
            sd = client_socket[i];  
                 
            if (FD_ISSET( sd , &readfds))  
            {  
                //Check if it was for closing , and also read the 
                //incoming message 

                if ((valread = read(sd, buffer, maxBufferSize)) == 0)  
                {  
                    //Somebody disconnected , get the details and print 
                    getpeername(sd, (struct sockaddr*)&serv_addr , \
                        (socklen_t*)&addrlen);
                    printf("Host disconnected , ip %s , port %d \n" , 
                          inet_ntoa(serv_addr.sin_addr) , ntohs(serv_addr.sin_port));  
                         
                    //Close the socket and mark as 0 in list for reuse 
                    close(sd);  
                    client_socket[i] = 0; 
                     
                } else if (valread < 0) {
                    perror("error in reading incoming message:");
                    return -1;
                } else { 
                    //set the string terminating NULL byte on the end 
                    //of the data read 
                    cout << "receive a message\n";

                    buffer[valread] = '\0';
                    string line = string(buffer);
                    stringstream ss(line);
                    readline.clear();
                    while (getline(ss,line,':')){
                        readline.push_back(line);
                    }
                    line = readline[1];
                    pid = readline[0];

                    int n = stoi(line.substr(1,(int)line.size()));
                    taskNum++;

                    //if first task, start time here
                    if(taskNum == 1){
                        //todo:time cout???
                        start =(duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count())/1000;
                    }

                    double time = (duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count());
                    time = time/1000;

                    sprintf(outputBuffer,"%.2f #%3d (T%3d) from %s\n", time, taskNum, n, pid.c_str());
                    cout << outputBuffer;
                    myfile << outputBuffer;


                    Trans(n);
                    line = "D" + to_string(taskNum);
                    char in[line.length()]; 
                    strcpy(in, line.c_str());

                    time = (duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count());
                    time = time/1000;
                    sprintf(outputBuffer,"%.2f #%3d (Done) from %s\n", time, taskNum, pid.c_str());
                    cout << outputBuffer;
                    myfile << outputBuffer;


                    if(write(sd, &in, sizeof(in))<0){
                        perror ("write");
                        exit(-1);
                    
                    }

                    bool found = false;
                    for (uint i = 0; i<pids.size(); i++){
                        if (pids[i] == pid){
                            found =true;
                            tran[i] ++;
                        }
                    }
                    
                    if (!found){
                       pids.push_back (pid);
                       tran.push_back(1);
                    }                    

                }  
            }
        }   
    }
    return 0; 
}

