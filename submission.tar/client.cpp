#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 
#include <cstring>
#include <string>

#include <boost/lexical_cast.hpp>
#include <cctype>
#include <fstream>
#include <iostream>
#include <netdb.h> 
#include <sstream>
#include <vector>
#include <chrono>
#include <sys/time.h>
using namespace std::chrono;
using namespace std;
#include <math.h> 

#include "trands.cpp"


//https://stackoverflow.com/questions/6012663/get-unix-timestamp-with-c
//https://www.geeksforgeeks.org/tcp-server-client-implementation-in-c/

int main(int argc, char** argv){

    if (argc != 3){
        //don't accept if there is less than or more than 3 arguments
        cout << "invalid # of arguments, exiting\n";
        return -1;
    }

    int maxBufferSize = 1024;
    string input;                       //input from input file or stdin, read line by line
    string ciient_id;                   //id of ciient hostname+pid
    string outputFile;                  //name of output file (logfile)
    ofstream myfile;                    //the file to write to


    char hostname[maxBufferSize];       //stores the hostname
    char outputBuffer[maxBufferSize];   //stores output string before printing out
    char msg_to_send[maxBufferSize];    //stores the message sent to the server
    char msg_receive[maxBufferSize];    //stores the message received from the server
    
    int transCount = 0;                 //keep track on #of trans sent to server

    int sockfd,connfd;
	struct sockaddr_in servaddr;

    int port = atoi(argv[1]);
    char* address = argv[2];
    int pid = getpid();

	//socket
	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0){
		perror("socket creation failed:");
		exit(-1);
	} else {
        cout << "socket created succesfully\n";
    }

    bzero(&servaddr, sizeof(servaddr));

    //assign IP, PORT
    servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr(address);
	servaddr.sin_port = htons(port);

    connfd = connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));
	if(connfd < 0){
		perror("connection with the server failed:");
		exit(-1);
	} else {
        cout << "connected to server\n";
    }
    
    gethostname(hostname, maxBufferSize); //get ther hostname

    ciient_id = string(hostname)  + "." +  to_string(pid);
	outputFile = string(hostname)  + "." +  to_string(pid) + ".log";
    myfile.open(outputFile.c_str());

    sprintf(outputBuffer,"Using port %d \nUsing server address %s \nHost %s \n", port, address, ciient_id.c_str());
    cout << outputBuffer;
    myfile << outputBuffer;


    //open outputFIle

    while (getline(cin, input)){
        // skip invalid input (space or missing command name/param)
        if (input.size() < 2){
            continue;
        }

        //for trans command
        if (input[0] == 'T'){
            
            ++transCount;

            //https://stackoverflow.com/questions/19555121/how-to-get-current-timestamp-in-milliseconds-since-1970-just-the-way-java-gets
            double time = (duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count());
            time = time/1000;
            sprintf(outputBuffer,"%.2f %s (%s%3d)\n", time, "Send", "T", stoi(input.substr(1, (int)input.size())));
            cout << outputBuffer;
            myfile << outputBuffer;
            			
			input = ciient_id + ":" + input; 
            strcpy(msg_to_send, input.c_str());

            if(write(sockfd, &msg_to_send, input.length())<0){
                perror ("write");
                exit(-1);
            }

            int nread;
            if ((nread = read(sockfd, &msg_receive, sizeof(msg_receive)-1))<0){
              perror("read");
              exit(-1);
            }
            msg_receive[nread]='\0';
			input = string(msg_receive);
            if (input[0] == 'D'){
                time = (duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count());
                time = time/1000;
                sprintf(outputBuffer,"%.2f %s (%s%3d)\n", time, "Recv", "D", stoi(input.substr(1, (int)input.size())));
                cout << outputBuffer;
                myfile << outputBuffer;
            }
        }
        if (input[0] == 'S'){
            // sleep, copied from my assignment2 code
            //https://linuxhint.com/remove-first-character-string-cpp/#:~:text=Example%201%3A%20Remove%20the%20First,from%20a%20string%20in%20place.
            //https://forums.codeguru.com/showthread.php?559457-RESOLVED-Leave-only-numeric-characters-in-std-string
            input.erase(std::remove_if(input.begin(), input.end(),
                            [](char c) { return !std::isdigit(c); }),input.end());
            //https://stackoverflow.com/questions/12628428/convert-stdstring-to-integer
            int unit = boost::lexical_cast<int>(input);

            sprintf(outputBuffer,"Sleep %d units\n", unit);
            cout << outputBuffer;  
            myfile << outputBuffer;

            Sleep(unit);
        }
       	
    }


    // close the socket
    close(sockfd); 
    
    sprintf(outputBuffer,"Sent %d transactions \n", transCount);
    cout << outputBuffer;
    myfile << outputBuffer;

    //close file
    myfile.close();

    return 0;
}